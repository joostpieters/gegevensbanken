<?php
define('SCRIPTPATH','gegevensbanken/gegevensbanken/scheepvaart/phpChart_Lite/');//VINCENT
//define('SCRIPTPATH','scheepvaart/phpChart_Lite/');//NIELS & PIETER
define('DEBUG', true);





/******** DO NOT MODIFY ***********/
require_once('phpChart.php');     
/**********************************/
?>
